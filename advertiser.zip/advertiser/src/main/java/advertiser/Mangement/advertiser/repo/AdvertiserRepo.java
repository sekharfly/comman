package advertiser.Mangement.advertiser.repo;

import org.springframework.data.repository.CrudRepository;

import advertiser.Mangement.advertiser.model.Advertiser;

public interface AdvertiserRepo extends CrudRepository<Advertiser, Long> {

}
