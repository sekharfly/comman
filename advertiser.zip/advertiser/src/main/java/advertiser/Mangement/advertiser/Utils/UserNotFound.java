package advertiser.Mangement.advertiser.Utils;

public class UserNotFound extends Exception {

	public UserNotFound(String exception) {
		super(exception);

	}
}
