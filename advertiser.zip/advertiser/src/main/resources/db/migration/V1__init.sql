--accounts
create table advertiser (
  id long, 
  advertiserName varchar(64),
  advertiserContactName varchar(64),
  advertiserCreditLimit varchar(64)
) 

